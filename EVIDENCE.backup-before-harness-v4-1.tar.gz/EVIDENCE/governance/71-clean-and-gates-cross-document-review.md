# Cross-Document Consistency Review

| Rule area | Canonical document | Summarized in | Gate | Conflict? | Decision |
|---|---|---|---|---|---|
| ServiceProvider requirement | `how-to-dependency-injection.md` §4.0 | `how-to-coding-standards.md` | `check-serviceprovider-governance-consistency.php` | None | All aligned |
| Semantic PHPDoc | `how-to-document.md` | `how-to-code-review.md` §24, `how-to-clean-code.md`, `how-to-code-style.md`, `how-to-production-readiness.md` | `check-semantic-phpdoc.php` | None | All aligned |
| Canonical terms | `docs/governance/canonical-terms.md` | `how-to-architecture.md` §27.4 | `check-canonical-terms.php` | None | All aligned |
| Security Must Scream | `how-to-system-security.md` §51 | 3 other docs | `check-security-commit-block-readiness.php` | None | All aligned |
| Security Commit Block | `how-to-system-security.md` §53 | 3 other docs | `check-security-commit-block-readiness.php` | None | All aligned |
| Status State Machine | `how-to-production-readiness.md` §17 | Dispersed | Manual | None | Single canonical source |
| Quality Ratchet | `how-to-production-readiness.md` §16 | `how-to-code-review.md` §14.1 | `check-quality-ratchet.php` | None | All aligned |
| Gate Self-Test | `how-to-code-review.md` §14.2 | `how-to-production-readiness.md` §14 | `check-gate-self-tests.php` | None | All aligned |
| Zero-scan gate | `how-to-code-review.md` §14.3 | `how-to-production-readiness.md` §15 | Manual | None | All aligned |
| Large Unit thresholds | `how-to-code-review.md` §21 | 2 other docs | `check-large-unit-thresholds.php` | None | All aligned |
| Component Status Ownership | `how-to-production-readiness.md` §18 | `how-to-design-components.md` §28 | Manual | None | All aligned |
| PublicSurface Factory | `how-to-architecture-extension-with-ddd.md` §11 | 2 other docs | Manual | None | All aligned |
| DDD Factory Boundary | `how-to-architecture-extension-with-ddd.md` §28.7 | 2 other docs | Manual | None | All aligned |
| Runtime composition | `how-to-runtime-composition.md` | `how-to-dependency-injection.md` | `check-runtime-composition-leaks.php` | None | All aligned |
| DI hidden fallback | `how-to-dependency-injection.md` | `how-to-runtime-composition.md` | `check-direct-instantiation.php` | None | All aligned |

## Verdict

All 15 rule areas are consistent across all documents with no remaining conflicts.
